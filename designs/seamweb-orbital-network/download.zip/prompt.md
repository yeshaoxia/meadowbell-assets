# 中文复现提示词

制作一个可独立运行、具有专业动效细节的 SeamWeb 创意平台首屏。只做一个屏幕，不添加下拉页面。

视觉：接近纯黑的 #050909 背景，荧光绿 #caff00 主按钮，白色两行标题“灵感在此汇聚，让创作自然发生。”，灰色说明“从设计灵感到动态交互，为你的下一个作品找到起点。”。左侧文案、两个按钮、三列数据；右侧镜面金属四瓣 Logo；底部技术名称横排。导航不带下拉箭头，字体精细，留白整齐。使用 Noto Sans SC 并把必要字体打包本地。

使用 Three.js 将项目中的 SeamWeb SVG 路径挤出，深度 5.5、倒角宽 1.7、厚度 1.5、9 段倒角。石墨色金属、柔和反射和清漆层；自动转动 0.12 rad/s。鼠标进入与移出时用指数缓动平滑调整姿态，不允许突然闪跳。支持指针捕获和拖动旋转，松手后有阻尼惯性；旋转任何角度都不能被画布裁断。

背景 Canvas 绘制 7 条椭圆轨道，中心约在画面宽 73.5%、高 49%。横向半径比例为 .125/.18/.25/.32/.41/.51/.62，纵向为 .125/.16/.20/.245/.29/.335/.38，各层有少量不同倾角及相反转向。35 个主节点，20 个集中在内四层，其余分布外三层，初始相位使用黄金角；每个节点带放射连线与大小不等的灰色卫星粒子。

主节点沿轨道自动绕行并随纵深缩放。节点有小型偏心圆环围绕移动，透明度缓慢变化；悬停时连线平滑变为荧光绿、卫星粒子轻微聚拢、圆环渐亮并有淡出反馈。轨道悬停只让局部弧线变亮，不要波浪、抖动或闪烁。低频背景流星每 10.5 秒出现一次，持续 1.25 秒，细尾迹与低亮度头部，远离文本中心。

实现真实提示词复制、原生弹窗、导航入口、中英切换、暂停；适配桌面/平板/手机。尊重 prefers-reduced-motion，隐藏标签页时停止渲染。输出含完整内联代码的 index.html，提供可编辑源码与 npm 构建脚本，运行不依赖远程字体或 CDN。

本包为完整可运行的交互实现，直接解压并打开 index.html。源码、字体、封面及演示视频均已包含。

## Pinned project files / 固定版本文件

- [index.html](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/index.html)
- [app.js](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/app.js)
- [style.css](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/style.css)
- [index.template.html](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/index.template.html)
- [font.css](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/font.css)
- [assets/cover.webp](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/cover.webp)
- [assets/demo-mini.mp4](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/demo-mini.mp4)
- [assets/seam-sans-0.woff2](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/seam-sans-0.woff2)
- [assets/seam-sans-1.woff2](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/seam-sans-1.woff2)
- [assets/seam-sans-2.woff2](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/seam-sans-2.woff2)
- [assets/seam-sans-3.woff2](https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/62b1b44553cb5fcecd7cd30b77fd6e9dec3d90fc/designs/seamweb-orbital-network/assets/seam-sans-3.woff2)
