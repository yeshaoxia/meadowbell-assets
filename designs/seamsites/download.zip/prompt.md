# SeamSites — Living Forest / Refined Edition

Build an immersive, full-viewport four-season forest website named SeamSites using a single HTML file with CSS, vanilla JavaScript, a WebGL2 procedural fog shader, and two Canvas 2D layers. Use the complete reference code below as the source of truth for an exact implementation. Preserve the supplied photographic assets: do not replace butterflies, dragonflies, petals, leaves, clouds or forest scenes with emoji, generic geometry, filters, or unrelated stock photography.

## Visual direction
Luxury editorial nature photography, calm typography, natural depth and unified light. A misty forest valley with a winding creek occupies the viewport. The interface is restrained and the natural motion is clearly visible. Light enters from the upper left, matching the forest photographs. Near wildlife and botanical elements have visible photographic texture; distant birds are small filled silhouettes with articulated wings. Never use drop shadows beneath airborne creatures.

## Assets (all included in the accompanying ZIP)
- assets/spring.webp — spring forest, fresh green, blossom and creek.
- assets/summer.webp — same forest in warm summer sunlight.
- assets/autumn.webp — same forest in copper and gold.
- assets/winter.webp — same forest in snow and blue twilight.
- assets/cloudscape.webp — independently generated photographic sky plate.
- assets/butterfly.webp — real transparent cutout of a pale yellow butterfly, spread wings, top view.
- assets/dragonfly.webp — real transparent cutout with fine translucent wings.
- assets/petal.webp — real transparent curved blush petal with subtle veins.
- assets/maple.webp — real transparent copper maple leaf with fine veins and curled tips.

## Public image URLs

- autumn.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/autumn.webp
- butterfly.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/butterfly.webp
- cloudscape.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/cloudscape.webp
- dragonfly.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/dragonfly.webp
- maple.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/maple.webp
- petal.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/petal.webp
- spring.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/spring.webp
- summer.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/summer.webp
- winter.webp: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/winter.webp

Use these exact URLs directly in the generated page, including dynamically loaded sprites. All nine image URLs point to the public GitHub asset directory.

## Interface
Instrument Sans. Full viewport 100svh, minimum height 650px. Header: outlined tree logo and SeamSites; navigation The seasons / Our philosophy / Field notes; pale pill Find your stillness; circular menu. Main headline, two lines: “A forest for” / “every feeling.” Eyebrow “A LITTLE CLOSER TO NATURE”. Supporting copy: “Four seasons. A thousand shades of quiet.” / “Step outside the ordinary. Find yourself here.”
Bottom centered glass panel with four buttons: Spring — Awaken & renew; Summer — Wander & breathe; Autumn — Slow & reflect; Winter — Rest & restore. Seasonal active button tint, live caption, seasonal index, small footer and Pause ambience / Play ambience button. Keep the complete reference's poetic captions and dialog content. Use native dialogs with working seasonal navigation, close button, Escape, and backdrop dismissal. No fake bookings or invented claims.

## Layering and art direction
1. Independent sky canvas, stationary during scene transitions. Blend four sky palettes: green teal spring, blue and gold summer, slate and copper autumn, silver blue winter. Blend and drift two photographic cloud-plate layers at different speeds and scales. Broad diffuse sunlight at 17% viewport width / 16% height; avoid a hard flat sun disk.
2. Feather-masked forest photo; only this scene moves vertically when changing seasons.
3. Subtle gradient shade and continuous WebGL2 mist, using domain-warped five-octave noise and season-specific fog color and density.
4. Foreground nature canvas: soft canopy shadows, feathered volumetric light shafts, horizontally drifting valley haze, textured wildlife and botanical particles.
5. Temporary opaque transition veil.
6. Interface above all atmosphere. Keep type and controls readable.

## Seasonal motion
Spring: four photographic yellow butterflies in different depth planes, about 30–62px desktop width. Split each source image into left and right wing halves and animate their horizontal compression, retain a natural body silhouette. Flight follows slow curved paths; wings flutter faster than the flight path. Drifting photographic petals rotate and tumble with variable scale, opacity and slight foreground blur. Green teal valley mist moves beneath the trees.
Summer: three detailed photographic dragonflies around 35–64px width; rapid wing compression and a faint wing-motion ghost, restrained curved flight. Clearly visible soft golden light shafts from upper left, slowly changing direction and intensity. Warm dust localized in the light path. Small golden-green firefly cores with layered soft halos in shaded lower forest, not uniformly distributed across bright sky. Distant filled birds travel across the valley.
Autumn: 24 mobile / 38 desktop photographic maple leaves, around 15–38px. Rotate continuously with oscillating foreshortening; vary size, opacity, speed and focus. A distant V-shaped flock crosses the valley. Copper and cream mist; softer lower light.
Winter: 130 mobile / 230 desktop snowflakes. Several depth scales; far flakes are tiny and slow, near flakes larger and blurred, lateral wind and drifting downward motion. Cool silver-blue mist, restrained winter light, three distant birds. Avoid snowflake emoji and decorative giant star shapes.

## Animation architecture and transitions
Use one requestAnimationFrame clock. Cap delta time at 50ms. Pause ambient time when the document is hidden. Continuous sky, mist and natural motion follow ambient time; the season switch follows transition time. Sink the forest 27% of viewport height over 300ms using smoothstep. Swap at the deepest point under the opaque veil, then rise over 1000ms using pow(1-x,3.4). Blend sky/light/fog palettes over 790ms starting at 60ms. Queue the most recent season click during a switch. Use the exact reference formulas for fog surge, UI dip and veil. No video, no visible timeline loop.
Render the WebGL fog at max width 960px, use premultiplied alpha. Use bounded particle counts. Cache soft light shafts to an offscreen canvas instead of recalculating blur every frame. Cap Canvas 2D pixel ratio at 1.5. Preserve the photographic scene if WebGL2 is unavailable.

## Accessibility and responsive behavior
Real buttons, aria-pressed on seasons and motion control, visible focus rings, polite live seasonal caption. Start with static atmosphere and instant season switching under prefers-reduced-motion, with explicit user opt-in to play ambiance. Under 820px retain logo and menu, hide desktop nav/side notes/header CTA, reduce wildlife sizes and particle counts, and retain the four-column selector. Preserve the image composition and legibility. All assets remain local so the ZIP works by opening index.html; the Google Font may fall back to the system font offline.


## Exact code

```html
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SeamSites — Living Forest · Refined Edition</title><meta name="description" content="Step into four seasons of stillness. An immersive forest experience by SeamSites."><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet"><style>
:root{--ink:#f5f7e9;--accent:#e3eeb4;--sink:0px;--dip:0;--veil:0}*{box-sizing:border-box}body{margin:0;background:#172d26;color:var(--ink);font-family:'Instrument Sans',sans-serif}button,a{-webkit-tap-highlight-color:transparent}button{font:inherit;cursor:pointer}a{color:inherit;text-decoration:none}button:focus-visible,a:focus-visible{outline:2px solid var(--accent);outline-offset:5px}.hero{height:100svh;min-height:650px;position:relative;overflow:hidden;isolation:isolate}.sky,.forest,.shade,#fog,.veil{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}.sky{background:#a0afa0}.sky img{width:100%;height:100%;object-fit:cover;filter:blur(12px);transform:scale(1.07)}.forest{transform:translate3d(0,var(--sink),0);will-change:transform;mask-image:linear-gradient(transparent 12%,#000 43%)}.forest img{position:absolute;width:100%;height:100%;object-fit:cover;object-position:center;visibility:hidden}.forest img.on{visibility:visible}.shade{background:linear-gradient(#102c2780,transparent 50%,#08231e60)}.veil{background:#c9d5c7;opacity:var(--veil)}#fog{z-index:1}.ui{position:relative;z-index:2;height:100%;display:flex;flex-direction:column;padding:26px 42px 28px}header{display:flex;align-items:center;justify-content:space-between;gap:24px}.logo{display:flex;align-items:center;gap:9px;font-size:25px;letter-spacing:-1px;font-weight:600}.logo svg{width:33px;height:33px;color:var(--accent)}nav{display:flex;gap:32px;font-size:14px}nav button{background:none;border:0;color:inherit;padding:10px 0}.right{display:flex;gap:20px;align-items:center}.pill{border:1px solid #ffffff50;border-radius:40px;background:var(--accent);color:#22372c;padding:14px 23px;font-size:13px;font-weight:600}.menu{border:1px solid #ffffff60;color:inherit;background:#ffffff0d;border-radius:50%;width:43px;height:43px;font-size:20px}.heading{text-align:center;margin-top:52px;opacity:calc(1 - var(--dip)*.65)}.eyebrow{font-size:11px;letter-spacing:3px;text-transform:uppercase;display:flex;align-items:center;justify-content:center;gap:10px}.eyebrow:before{content:'';width:5px;height:5px;background:var(--accent);border-radius:50%}h1{font-size:clamp(44px,4.7vw,76px);line-height:1.05;font-weight:400;letter-spacing:-3px;margin:18px 0}h1 em{font-style:normal;color:var(--accent)}.intro{font-size:14px;line-height:1.6;opacity:.8;margin:16px 0}.side-note{position:absolute;left:42px;top:53%;font-size:10px;letter-spacing:2px;writing-mode:vertical-rl;transform:rotate(180deg);opacity:.7}.season-note{position:absolute;right:42px;top:52%;text-align:right}.season-note small{font-size:9px;letter-spacing:2px;opacity:.6}.season-note p{font-size:14px;line-height:1.6;margin-top:10px}.dock{margin-top:auto;align-self:center;text-align:center;width:min(660px,100%)}.toggle{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;border:1px solid #ffffff40;padding:5px;border-radius:18px;background:#46574c66;backdrop-filter:blur(18px)}.toggle button{position:relative;border:0;background:none;color:#fff;border-radius:13px;padding:15px 10px}.toggle button[aria-pressed=true]{background:linear-gradient(145deg,#f4f7df,var(--accent));color:#23382b;box-shadow:inset 0 0 18px #ffffff70}.toggle b{font-size:18px;font-weight:500;display:block}.toggle small{display:block;font-size:10px;opacity:.65;margin-top:5px}.toggle .icon{display:inline-block;font-size:18px;margin-bottom:6px}.caption{font-size:12px;opacity:.8;margin:17px 0 0}.footer{display:flex;justify-content:space-between;align-items:center;font-size:9px;letter-spacing:1.5px;opacity:.65;margin-top:30px}.footer span:nth-child(2){letter-spacing:0}.mobile-only{display:none}dialog{border:1px solid #c8d5bd50;background:#142d26ed;backdrop-filter:blur(25px);color:#f1f4e5;border-radius:22px;width:min(640px,calc(100% - 32px));padding:36px;box-shadow:0 30px 120px #0008}dialog::backdrop{background:#071b1780;backdrop-filter:blur(7px)}dialog h2{font-size:38px;letter-spacing:-1px;font-weight:400;margin:12px 0}dialog p{line-height:1.8;color:#c5d0c3}dialog .close{float:right;color:inherit;background:none;border:0;font-size:25px}dialog .choices{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:22px}dialog .choices button{text-align:left;padding:20px;border:1px solid #ffffff30;border-radius:12px;background:#ffffff08;color:inherit}dialog .choices small{display:block;opacity:.6;margin-top:6px} @media(min-width:1800px){.ui{padding:36px 60px}.heading{margin-top:70px}}@media(max-width:820px){.ui{padding:18px 20px 22px}nav,.right .pill,.season-note,.side-note{display:none}.logo{font-size:23px}.heading{margin-top:64px}h1{font-size:clamp(44px,9vw,64px);letter-spacing:-2px}.intro{font-size:13px}.toggle b{font-size:15px}.toggle button{padding:13px 4px}.toggle small{font-size:9px}.footer{margin-top:24px;font-size:8px}.footer span:nth-child(2){display:none}.forest img,.sky img{object-position:50% center}.hero{min-height:650px}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto}}
#atmosphere,#nature{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}#nature{z-index:1}.veil{z-index:1}.forest{mask-image:linear-gradient(transparent 13%,#000 44%)}.heading{text-shadow:0 2px 24px #102c2740}.footer #motion{font:inherit;letter-spacing:.3px;border:1px solid #ffffff40;background:#14342c40;color:inherit;border-radius:30px;padding:8px 13px;cursor:pointer}.footer{opacity:.85}.sky{background:linear-gradient(#557e85,#d5e2bf)}@media(max-width:820px){.footer #motion{font-size:8px;padding:7px 9px}.footer span:first-child{max-width:95px;line-height:1.6}}</style></head><body><main class="hero"><div class="sky"><canvas id="atmosphere" aria-hidden="true"></canvas></div><div class="forest" id="forest"><img id="scene0" class="on" src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/spring.webp" alt="A misty forest valley and winding creek in spring" fetchpriority="high"><img id="scene1" class="" src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/summer.webp" alt="A misty forest valley and winding creek in summer" fetchpriority="auto"><img id="scene2" class="" src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/autumn.webp" alt="A misty forest valley and winding creek in autumn" fetchpriority="auto"><img id="scene3" class="" src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/winter.webp" alt="A misty forest valley and winding creek in winter" fetchpriority="auto"></div><div class="shade"></div><canvas id="fog" aria-hidden="true"></canvas><canvas id="nature" aria-hidden="true"></canvas><div class="veil"></div><div class="ui"><header><a href="./" class="logo" aria-label="SeamSites home"><svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M20 3 7 25h8L9 35h22l-6-10h8L20 3Z" stroke="currentColor" stroke-width="1.6"/><path d="M20 13v24M13 24l7 5 7-5" stroke="currentColor" stroke-width="1.6"/></svg>SeamSites</a><nav aria-label="Main navigation"><button data-panel="seasons">The seasons</button><button data-panel="philosophy">Our philosophy</button><button data-panel="journal">Field notes ↗</button></nav><div class="right"><button class="pill" data-panel="explore">Find your stillness ↗</button><button class="menu" aria-label="Open menu" data-panel="menu">☰</button></div></header><section class="heading"><div class="eyebrow">A little closer to nature</div><h1>A forest for<br><em>every feeling.</em></h1><p class="intro">Four seasons. A thousand shades of quiet.<br>Step outside the ordinary. Find yourself here.</p></section><div class="side-note">EST. IN STILLNESS — SEAMSITES</div><aside class="season-note"><small id="index">01 / 04 — SPRING</small><p id="note">Where the world<br>begins again.</p></aside><div class="dock"><div class="toggle" role="group" aria-label="Choose a forest season"><button data-season="0" aria-pressed="true"><span class="icon" aria-hidden="true">✳</span><b>Spring</b><small>Awaken & renew</small></button><button data-season="1" aria-pressed="false"><span class="icon" aria-hidden="true">☀</span><b>Summer</b><small>Wander & breathe</small></button><button data-season="2" aria-pressed="false"><span class="icon" aria-hidden="true">❧</span><b>Autumn</b><small>Slow & reflect</small></button><button data-season="3" aria-pressed="false"><span class="icon" aria-hidden="true">❄</span><b>Winter</b><small>Rest & restore</small></button></div><p class="caption" id="caption" aria-live="polite">Follow the first green. Let a new beginning find you.</p></div><footer class="footer"><span>FOUR SEASONS / ONE WILD WORLD</span><button id="motion" aria-pressed="false" aria-label="Pause or play ambient animation">Pause ambience Ⅱ</button><span id="season-footer">SPRING — 01</span></footer></div></main><dialog id="panel"><button class="close" aria-label="Close dialog">×</button><div class="eyebrow" style="justify-content:flex-start">SeamSites / Into the wild</div><h2 id="panel-title"></h2><div id="panel-body"></div></dialog><script>
const root=document.documentElement.style,$=id=>document.getElementById(id);const calm=matchMedia('(prefers-reduced-motion:reduce)').matches;
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));const smooth=(a,b,x)=>{x=clamp((x-a)/(b-a));return x*x*(3-2*x)};
const cv=$('fog'),gl=cv.getContext('webgl2',{alpha:true,premultipliedAlpha:true,antialias:false});
let U={};
if(gl){
  const vs=`#version 300 es
  void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0,1);}`;
  const fs=`#version 300 es
  precision highp float;
  uniform vec2 R;uniform float T,S,K,F;uniform vec3 A,B;out vec4 O;
  float h(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
  float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
    return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}
  float fbm(vec2 p){float a=.5,s=0.;mat2 m=mat2(1.6,1.2,-1.2,1.6);p=mat2(.8,.6,-.6,.8)*p+5.3;for(int i=0;i<5;i++){s+=a*n(p);p=m*p;a*=.5;}return s;}
  void main(){
    vec2 uv=gl_FragCoord.xy/R;uv.y=1.-uv.y;
    float asp=R.x/R.y;vec2 p=vec2(uv.x*asp,uv.y);
    float t=T*.05;
    vec2 w=vec2(fbm(p*1.3+vec2(t,-t*.6)),fbm(p*1.3+vec2(-t*.8,t)+7.));
    float d=fbm(p*1.9+w*1.7+vec2(t*1.6,-t*1.1+S*.5));
    float e=fbm(p*.9-w+vec2(-t,t*.5)+3.);
    float low=smooth2(.70,1.04,uv.y+(d-.5)*.34);
    float side=smooth2(.2,.0,uv.x+(e-.5)*.28)+smooth2(.8,1.,uv.x+(e-.5)*.28);
    side*=smooth2(.25,.6,uv.y)*.2;
    float wisps=smooth2(.5,.78,d)*smooth2(.22,.5,uv.y)*smooth2(.86,.6,uv.y)*.18;
    float rest=clamp((low+side+wisps)*F,0.,1.);
    float front=1.02-S*.68;
    float rise=smooth2(front-.02,front+.26,uv.y+(d-.5)*.5);
    float haze=S*(.3+.46*d);
    float a=clamp(max(rest,max(rise*.97,haze)),0.,1.);
    vec3 dayA=vec3(.86,.92,.82),dayB=vec3(.47,.58,.47);
    vec3 nitA=vec3(.40,.45,.57),nitB=vec3(.15,.19,.29);
    vec3 c=mix(B,A,clamp(d*1.15,0.,1.));
    float porch=exp(-dot((uv-vec2(.72,.74))*vec2(1.7,2.6),(uv-vec2(.72,.74))*vec2(1.7,2.6))*3.2);
    
    O=vec4(c*a,a);
  }`.replace(/smooth2/g,'smoothstep');
  const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);
    if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))console.error(gl.getShaderInfoLog(o));return o};
  const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,vs));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,fs));
  gl.linkProgram(pr);gl.useProgram(pr);
  for(const u of['R','T','S','K','A','B','F'])U[u]=gl.getUniformLocation(pr,u);
}
function size(){
  if(!gl)return;
  const w=Math.round(Math.min(innerWidth,960)),h=Math.round(w*innerHeight/innerWidth);
  if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;gl.viewport(0,0,w,h)}
}
addEventListener('resize',size);size();


const seasons=['spring','summer','autumn','winter'],accents=['#e3eeb4','#c9e5b7','#f1d2a3','#d8e9ef'],captions=['Follow the first green. Let a new beginning find you.','Lose track of time beneath a canopy of green.','Let go with the leaves. Make room for a slower rhythm.','In the quiet of winter, discover the beauty of being still.'],notes=['Where the world<br>begins again.','Nothing to rush.<br>Everything to feel.','The art of<br>letting go.','A softer world.<br>A quieter mind.'];
let current=0,target=0,queued=null,start=0,active=false,swapped=false,clock=0,k=0,from=0;
function show(n){current=n;seasons.forEach((s,i)=>$('scene'+i).classList.toggle('on',i===n));$('caption').textContent=captions[n];$('note').innerHTML=notes[n];$('index').textContent=`0${n+1} / 04 — ${seasons[n].toUpperCase()}`;$('season-footer').textContent=seasons[n].toUpperCase()+' — 0'+(n+1);document.querySelectorAll('[data-season]').forEach(b=>b.setAttribute('aria-pressed',Number(b.dataset.season)===n));root.setProperty('--accent',accents[n]);}
function begin(n,t){envFrom=envWeights.slice();target=n;start=t;active=true;swapped=false;from=k}
function pick(n){if(calm){show(n);target=n;k=n===3?1:0;requestAnimationFrame(frame);return}if(active){queued=n;return}if(n!==current)begin(n,performance.now())}
document.querySelectorAll('[data-season]').forEach(b=>b.onclick=()=>pick(Number(b.dataset.season)));
function frame(now){clock=now;let y=0,s=0,dip=0,veil=0;if(active){let d=now-start;if(d<300)y=smooth(0,300,d)*.27;else{if(!swapped){show(target);swapped=true}y=Math.pow(1-clamp((d-300)/1000),3.4)*.27}s=smooth(0,250,d)*(1-smooth(430,1220,d));dip=smooth(20,220,d)*(1-smooth(460,1000,d));veil=smooth(50,260,d)*(1-smooth(350,820,d));k=from+((target===3?1:0)-from)*smooth(120,700,d);if(d>=1300){active=false;y=s=dip=veil=0;let q=queued;queued=null;if(q!==null&&q!==current)begin(q,now)}}root.setProperty('--sink',y*innerHeight+'px');root.setProperty('--dip',dip);root.setProperty('--veil',veil);atmosphereFrame(now,s);if(gl){gl.uniform2f(U.R,cv.width,cv.height);gl.uniform1f(U.T,weatherTime);gl.uniform1f(U.S,s);gl.uniform1f(U.K,k);gl.drawArrays(gl.TRIANGLES,0,3)}if(!calm||!paused)requestAnimationFrame(frame)}requestAnimationFrame(frame);
const content={philosophy:['Less noise. More nature.','<p>SeamSites is an invitation to slow down. To notice the light between branches, the rhythm of water, and the small changes that make each season its own world.</p><p>This digital forest is an imaginative escape. There is no itinerary to finish. Just a moment to return to yourself.</p>'],journal:['Notes from the forest.','<p><strong>01 / Look closer</strong><br>Spring is written in the smallest details: an unfurling fern, a fresh leaf, the first blossom above the creek.</p><p><strong>02 / Walk without a destination</strong><br>Summer asks for nothing but your attention. Follow the water. Pause in the shade.</p><p><strong>03 / Make space for quiet</strong><br>Autumn lets go. Winter rests. There is something to learn from both.</p>']};
function openPanel(key){let pair=content[key];$('panel-title').textContent=pair?pair[0]:key==='menu'?'A way into the wild.':'Choose your season.';$('panel-body').innerHTML=pair?pair[1]:'<p>Every season offers a different way to pause. Choose the forest that meets you where you are.</p><div class="choices">'+seasons.map((s,i)=>`<button data-choice="${i}">${s[0].toUpperCase()+s.slice(1)} ↗<small>${captions[i]}</small></button>`).join('')+'</div>';$('panel').showModal();document.querySelectorAll('[data-choice]').forEach(b=>b.onclick=()=>{$('panel').close();pick(Number(b.dataset.choice))})}document.querySelectorAll('[data-panel]').forEach(b=>b.onclick=()=>openPanel(b.dataset.panel));document.querySelector('.close').onclick=()=>$('panel').close();$('panel').onclick=e=>{if(e.target===$('panel')){const r=$('panel').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('panel').close()}};
// Photographic materials, one ambient clock, coherent illumination.
const skyCanvas=$('atmosphere'),skyCtx=skyCanvas.getContext('2d'),fxCanvas=$('nature'),fx=fxCanvas.getContext('2d');
const palettes=[
 {top:'#799fa2',horizon:'#dce9ce',cloud:'#edf6e5',sun:'#fff2c0',fogA:[.73,.88,.78],fogB:[.26,.49,.43],wind:7,clouds:.4},
 {top:'#659da8',horizon:'#f6dfaa',cloud:'#fff2cd',sun:'#ffe9ac',fogA:[.91,.87,.69],fogB:[.40,.50,.37],wind:5,clouds:.25},
 {top:'#8e9197',horizon:'#eac49d',cloud:'#f3dfc9',sun:'#ffd79f',fogA:[.86,.75,.62],fogB:[.46,.42,.36],wind:12,clouds:.45},
 {top:'#647e9b',horizon:'#dae5eb',cloud:'#e1edf4',sun:'#edf5ff',fogA:[.78,.86,.93],fogB:[.37,.47,.60],wind:9,clouds:.55}
];
let envWeights=[1,0,0,0],envFrom=[1,0,0,0],weatherTime=0,lastWeather=0,paused=calm,W=1,H=1;
const rand=n=>{let x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)},mod=(n,m)=>(n%m+m)%m;
const rays=document.createElement('canvas'),rc=rays.getContext('2d');
const materials={};for(const name of['butterfly','dragonfly','petal','maple','cloudscape']){let im=new Image();im.onload=()=>{materials[name]=im;if(paused)renderNature(weatherTime,0)};im.src='https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/assets/'+name+'.webp'}
function fitNature(){W=innerWidth;H=innerHeight;const d=Math.min(devicePixelRatio||1,1.5);for(const c of[skyCanvas,fxCanvas]){c.width=Math.round(W*d);c.height=Math.round(H*d);c.getContext('2d').setTransform(d,0,0,d,0,0)}
 rays.width=Math.ceil(W*.6);rays.height=Math.ceil(H*.6);rc.setTransform(.6,0,0,.6,0,0);rc.clearRect(0,0,W,H);rc.filter='blur(20px)';
 for(let j=0;j<7;j++){const sourceX=W*.17,sourceY=-H*.09,end=W*(.19+j*.13),width=W*(j%2?.026:.047);let g=rc.createLinearGradient(sourceX,0,end,H);g.addColorStop(0,'#fff6d400');g.addColorStop(.15,'#fff4cfc0');g.addColorStop(.5,'#fff1c99c');g.addColorStop(.85,'#ffefc54a');g.addColorStop(1,'#ffefc500');rc.fillStyle=g;rc.beginPath();rc.moveTo(sourceX,sourceY);rc.lineTo(end+width,H);rc.lineTo(end-width,H);rc.closePath();rc.fill()}rc.filter='none';if(paused)renderNature(weatherTime,0)}
function rgbMix(key){let a=[0,0,0];palettes.forEach((p,i)=>p[key].forEach((v,j)=>a[j]+=v*envWeights[i]));return a}
function cover(c,im,x,y,w,h){const sc=Math.max(w/im.width,h/im.height),dw=im.width*sc,dh=im.height*sc;c.drawImage(im,x+(w-dw)/2,y+(h-dh)/2,dw,dh)}
function glow(c,x,y,r,color,alpha){c.save();c.globalAlpha*=alpha;let g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color+'b0');g.addColorStop(.18,color+'55');g.addColorStop(.6,color+'16');g.addColorStop(1,color+'00');c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore()}
function renderSky(t){skyCtx.clearRect(0,0,W,H);palettes.forEach((p,i)=>{const weight=envWeights[i];if(weight<.001)return;skyCtx.save();skyCtx.globalAlpha=weight;const g=skyCtx.createLinearGradient(0,0,0,H*.62);g.addColorStop(0,p.top);g.addColorStop(1,p.horizon);skyCtx.fillStyle=g;skyCtx.fillRect(0,0,W,H);
 if(materials.cloudscape){skyCtx.save();skyCtx.globalAlpha=weight*[.65,.52,.68,.78][i];skyCtx.globalCompositeOperation='soft-light';let drift=Math.sin(t*.012)*W*.06;cover(skyCtx,materials.cloudscape,-W*.12+drift,-H*.07,W*1.24,H*.7);skyCtx.restore();skyCtx.save();skyCtx.globalCompositeOperation='screen';skyCtx.globalAlpha=weight*.12;cover(skyCtx,materials.cloudscape,-W*.24-Math.sin(t*.019)*W*.055,-H*.14,W*1.5,H*.64);skyCtx.restore()}
 // The broad, diffused source agrees with the sunlight in the forest plate.
 glow(skyCtx,W*.17,H*.16,W*.48,p.sun,.8);skyCtx.restore()})}
function bird(x,y,s,t){fx.save();fx.translate(x,y);fx.rotate(.07*Math.sin(t*.6));fx.fillStyle='#283b3ed9';const flap=Math.sin(t)*s*.6;fx.beginPath();fx.moveTo(-1,1);fx.bezierCurveTo(-s*.35,-s*.22,-s*.73,flap*.7,-s,flap);fx.bezierCurveTo(-s*.75,flap-s*.25,-s*.22,-s*.38,0,-1);fx.bezierCurveTo(s*.22,-s*.38,s*.75,flap-s*.25,s,flap);fx.bezierCurveTo(s*.73,flap*.7,s*.35,-s*.22,1,1);fx.lineTo(1.8,4);fx.lineTo(0,3);fx.lineTo(-1.8,4);fx.closePath();fx.fill();fx.beginPath();fx.ellipse(0,-.3,1.15,s*.3,0,0,Math.PI*2);fx.fill();fx.restore()}
function butterfly(x,y,s,t){let im=materials.butterfly;if(!im)return;fx.save();fx.translate(x,y);fx.rotate(-.2+Math.sin(t*.9)*.22);const flap=.18+.82*Math.pow((Math.sin(t*22)+1)/2,.65),aspect=im.height/im.width;
 for(let side of[-1,1]){fx.save();fx.scale(flap,1);if(side<0)fx.drawImage(im,0,0,im.width/2,im.height,-s/2,-s*aspect/2,s/2,s*aspect);else fx.drawImage(im,im.width/2,0,im.width/2,im.height,0,-s*aspect/2,s/2,s*aspect);fx.restore()}fx.restore()}
function dragonfly(x,y,s,t){let im=materials.dragonfly;if(!im)return;fx.save();fx.translate(x,y);fx.rotate(.7+Math.sin(t*.7)*.2);let h=s*im.height/im.width;fx.save();fx.globalAlpha*=.2;fx.scale(1.08,1);fx.drawImage(im,-s/2,-h/2,s,h);fx.restore();fx.scale(.82+Math.abs(Math.sin(t*43))*.18,1);fx.drawImage(im,-s/2,-h/2,s,h);fx.restore()}
function floatingMaterial(name,x,y,w,t,seed,depth){const im=materials[name];if(!im)return;fx.save();fx.translate(x,y);fx.rotate(t*(name==='maple'?.58:.35)+seed);fx.scale(.3+.7*Math.abs(Math.cos(t*.8+seed)),1);fx.globalAlpha*=.65+depth*.35;fx.filter=depth>.88?'blur(1.2px)':'none';fx.drawImage(im,-w/2,-w*im.height/im.width/2,w,w*im.height/im.width);fx.restore()}
function renderNature(t,surge){renderSky(t);fx.clearRect(0,0,W,H);const ambient=1-surge*.9,mobile=W<820;
 palettes.forEach((p,season)=>{let a=envWeights[season]*ambient;if(a<.001)return;fx.save();fx.globalAlpha=a;
 // Broad moving canopy shadows, soft edged and confined below the skyline.
 fx.save();fx.globalCompositeOperation='multiply';for(let j=0;j<3;j++){let x=W*(.1+j*.4)+Math.sin(t*.12+j)*W*.025,y=H*.67;let g=fx.createRadialGradient(x,y,0,x,y,W*.31);g.addColorStop(0,'#163b3830');g.addColorStop(1,'#163b3800');fx.fillStyle=g;fx.fillRect(x-W*.31,y-W*.31,W*.62,W*.62)}fx.restore();
 fx.save();fx.globalCompositeOperation='screen';fx.globalAlpha=a*[.60,1,.48,.22][season]*(.78+Math.sin(t*.32)*.22);fx.translate(W*.17,-H*.09);fx.rotate(Math.sin(t*.055)*.018);fx.translate(-W*.17,H*.09);fx.drawImage(rays,0,0,W,H);fx.restore();
 // Low valley haze: soft plumes drift laterally beneath the typography.
 fx.save();fx.globalCompositeOperation='screen';for(let j=0;j<4;j++){let x=mod(W*rand(j+17)+t*(4+j),W*1.5)-W*.25,y=H*(.48+j*.07)+Math.sin(t*.2+j)*H*.012;fx.save();fx.translate(x,y);fx.scale(1,.12);let g=fx.createRadialGradient(0,0,0,0,0,W*.4);g.addColorStop(0,(season===0?'#a3d8c3':season===1?'#f0ddb2':season===2?'#dfc2a2':'#c0d7ec')+'48');g.addColorStop(.45,p.cloud+'20');g.addColorStop(1,p.cloud+'00');fx.globalAlpha=a*(season===0?.8:.55);fx.fillStyle=g;fx.fillRect(-W*.4,-W*.4,W*.8,W*.8);fx.restore()}fx.restore();
 let count=season===0?(mobile?23:35):season===1?28:season===2?(mobile?24:38):(mobile?130:230);
 for(let j=0;j<count;j++){const z=.18+rand(j+180)*.82;let x=mod(rand(j+2)*W+t*(season===2?23:season===3?12:11)*z+Math.sin(t*.7+j)*28*z,W+100)-50;let y=mod(rand(j+4)*H+t*(season===3?31:season===2?33:17)*z,H+100)-50;
 if(season===0||season===2){fx.globalAlpha=a*(.4+z*.55);floatingMaterial(season===0?'petal':'maple',x,y,(season===0?9:15)+z*(season===0?12:23),t,j,z)}
 else if(season===3){fx.save();fx.globalAlpha=a*(.22+z*.65);let r=.7+z*z*3.5;fx.filter=z>.89?'blur(1.8px)':'none';fx.fillStyle='#f3f9ff';fx.beginPath();fx.ellipse(x,y,r,r*(1+z*.25),.25,0,Math.PI*2);fx.fill();fx.restore()}
 else{y=H*(.57+rand(j+74)*.32)+Math.sin(t*.47+j)*16;x+=Math.sin(t*.75+j)*12;let pulse=.2+.8*Math.pow((Math.sin(t*1.6+j*2)+1)/2,3);fx.globalAlpha=a*pulse;glow(fx,x,y,13+z*10,'#eff5a3',.55);fx.fillStyle='#ffffd4';fx.beginPath();fx.arc(x,y,.7+z*.8,0,Math.PI*2);fx.fill()}}
 fx.globalAlpha=a;
 if(season===0){for(let j=0;j<(mobile?3:4);j++){const x=W*[.2,.77,.36,.88][j]+Math.sin(t*(.22+j*.05)+j*2)*W*.055,y=H*(.56+j*.047)+Math.sin(t*.8+j)*20;butterfly(x,y,[62,48,35,30][j]*(mobile?.72:1),t+j)}}
 if(season===1){for(let j=0;j<3;j++){let x=W*[.24,.76,.61][j]+Math.sin(t*.24+j*2)*W*.07,y=H*(.58+j*.057)+Math.sin(t*1.4+j)*6;dragonfly(x,y,[64,48,35][j]*(mobile?.75:1),t+j)}for(let j=0;j<5;j++){fx.globalAlpha=a*.6;bird(mod(t*23+W*.15+j*25,W+200)-100,H*.43+Math.abs(j-2)*9+Math.sin(t*.4)*9,7+rand(j)*3,t*5+j)}}
 if(season===2){for(let j=0;j<9;j++){fx.globalAlpha=a*.6;bird(mod(t*25+W*.05+j*24,W+300)-150,H*.42+Math.abs(j-4)*9,7,t*4.7+j*.4)}}
 if(season===3){for(let j=0;j<3;j++){fx.globalAlpha=a*.7;bird(mod(t*19+j*W*.36,W+150)-75,H*(.44+j*.018)+Math.sin(t*.4+j)*8,7,t*6+j)}}
 // Airborne sun dust is warm and localized to the light path.
 if(season<2){fx.globalCompositeOperation='screen';for(let j=0;j<20;j++){let x=W*(.12+rand(j+200)*.55)+Math.sin(t*.25+j)*12,y=H*(.4+rand(j+270)*.42)-mod(t*1.7+j,12);fx.globalAlpha=a*(.1+rand(j+310)*.25);glow(fx,x,y,2.5,'#fff1c5',.7)}}fx.restore()});
}
function atmosphereFrame(now,s){if(!paused&&!document.hidden)weatherTime+=Math.min((now-(lastWeather||now))/1000,.05);lastWeather=now;if(active){let v=smooth(60,850,now-start);envWeights=envFrom.map((w,i)=>w+(Number(i===target)-w)*v)}else envWeights=envWeights.map((w,i)=>Number(i===current));renderNature(weatherTime,s);if(gl){gl.uniform3fv(U.A,rgbMix('fogA'));gl.uniform3fv(U.B,rgbMix('fogB'));gl.uniform1f(U.F,current===1?.45:current===3?.8:.7)}}
$('motion').onclick=()=>{paused=!paused;$('motion').setAttribute('aria-pressed',String(paused));$('motion').textContent=paused?'Play ambience ▷':'Pause ambience Ⅱ';if(calm)requestAnimationFrame(frame)};
if(calm){$('motion').setAttribute('aria-pressed','true');$('motion').textContent='Play ambience ▷'}addEventListener('resize',fitNature);fitNature();

</script></body></html>
```

## Stable implementation reference

Reference HTML: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/seamsites/index.html

All repository image and implementation URLs above use the immutable commit `d3ac2df4b5d9d18c002268966b00c507b20ef029`. Download the ZIP for local assets and offline use. Keeping the repository public and retaining its history is still required for online links.
