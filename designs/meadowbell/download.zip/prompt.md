# Meadowbell — Asset Preview (not the original design brief)

The original design implementation and original generation prompt have not been archived. Recreate the supplied asset review page using the exact reference HTML below. Show the original loop.mp4 in a native controls-enabled video player with plate.jpg as poster, followed by a responsive two-column image gallery. Use a dark forest palette, system typography, rounded media frames and clear labels. Do not claim this is the original design. Keep the local ZIP offline-compatible.

## Verified repository assets

- https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-kite.jpg
- https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-path.jpg
- https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-water.jpg
- https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/loop.mp4
- https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/plate.jpg


## Exact HTML

```html
<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meadowbell · 素材预览</title><style>*{box-sizing:border-box}body{margin:0;background:#101715;color:#edf0e6;font:15px/1.7 system-ui,sans-serif}main{max-width:1180px;margin:auto;padding:32px 24px 64px}a{color:inherit}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #ffffff20;padding-bottom:24px}h1{font-size:clamp(36px,7vw,70px);letter-spacing:-2px;font-weight:450;margin:38px 0 4px}.label{letter-spacing:3px;font-size:11px;color:#bfccb5}.note{color:#afbeb5;max-width:660px}video{display:block;width:100%;max-height:72vh;background:#000;border:1px solid #ffffff25;border-radius:18px;margin:26px 0 42px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}figure{margin:0}img{width:100%;aspect-ratio:16/10;object-fit:cover;display:block;border-radius:14px}figcaption{font-size:12px;color:#a2b0a7;padding-top:10px}footer{margin-top:40px;border-top:1px solid #ffffff20;padding-top:20px;color:#a2b0a7}@media(max-width:640px){.grid{grid-template-columns:1fr}main{padding:22px 18px}}</style><main><header><a href="../../index.html">← 全部设计</a><span class="label">ASSET COLLECTION</span></header><h1>Meadowbell</h1><p class="note">素材预览页。这里展示仓库中已保存的图片和循环视频；原始设计页面源码、原始提示词尚未归档。</p><video controls loop playsinline preload="metadata" poster="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/plate.jpg"><source src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/loop.mp4" type="video/mp4">浏览器不支持视频播放，请下载素材包查看。</video><h2>图片素材</h2><div class="grid"><figure><img src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-kite.jpg" alt="Meadowbell — chapter-kite.jpg" loading="lazy"><figcaption>chapter-kite.jpg</figcaption></figure><figure><img src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-path.jpg" alt="Meadowbell — chapter-path.jpg" loading="lazy"><figcaption>chapter-path.jpg</figcaption></figure><figure><img src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/chapter-water.jpg" alt="Meadowbell — chapter-water.jpg" loading="lazy"><figcaption>chapter-water.jpg</figcaption></figure><figure><img src="https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/assets/plate.jpg" alt="Meadowbell — plate.jpg" loading="lazy"><figcaption>plate.jpg</figcaption></figure></div><footer>完整解压 download.zip 后打开 index.html，即可离线查看所有素材。</footer></main></html>
```

## Stable implementation reference

Reference HTML: https://raw.githubusercontent.com/yeshaoxia/meadowbell-assets/d3ac2df4b5d9d18c002268966b00c507b20ef029/designs/meadowbell/index.html

All repository image and implementation URLs above use the immutable commit `d3ac2df4b5d9d18c002268966b00c507b20ef029`. Download the ZIP for local assets and offline use. Keeping the repository public and retaining its history is still required for online links.
